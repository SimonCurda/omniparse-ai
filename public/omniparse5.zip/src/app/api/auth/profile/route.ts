import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest } from '@/lib/auth';

export async function PUT(req: Request) {
  const auth = await getUserFromRequest(req);
  if (!auth) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  let body: { name?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid request body' }, { status: 400 });
  }

  const { name } = body;

  if (name === undefined) {
    return NextResponse.json({ error: 'Name is required' }, { status: 400 });
  }

  if (typeof name !== 'string' || name.trim().length < 2) {
    return NextResponse.json(
      { error: 'Name must be at least 2 characters' },
      { status: 400 }
    );
  }

  if (name.length > 100) {
    return NextResponse.json(
      { error: 'Name must be at most 100 characters' },
      { status: 400 }
    );
  }

  const updated = await db.user.update({
    where: { id: auth.userId },
    data: { name: name.trim() },
    select: { id: true, email: true, name: true, plan: true, createdAt: true },
  });

  return NextResponse.json({ user: updated });
}
